﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quan_Ly_Ban_Sach
{
    public enum ChucVuQuanLy
    {
        NGUOI_COI_HO,
        CHI_QUAN_LY,
        ONG_GIAM_DOC,
        NGUOI_DOC_SACH,
        CHU_THU_VIEN
    }
}
