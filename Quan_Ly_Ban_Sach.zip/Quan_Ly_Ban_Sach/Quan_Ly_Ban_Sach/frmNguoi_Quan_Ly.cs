﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quan_Ly_Ban_Sach
{
    public partial class frmNguoi_Quan_Ly : Form
    {
        public frmQuanLySach AcForm = new frmQuanLySach();

        public frmNguoi_Quan_Ly()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnUpload_avatar_Click(object sender, EventArgs e)
        {
            OpenFileDialog fil = new OpenFileDialog();
            if(fil.ShowDialog() == DialogResult.OK)
            {
               
                btnUpload_avatar.Text = fil.FileName;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_hoanthanh_Click(object sender, EventArgs e)
        {
            if(txtName.Text == "" || btnUpload_avatar.Text == "Upload ảnh đại diện" || cbk_listChucVU.SelectedIndex == -1)
            {
                MessageBox.Show("Bạn chưa thêm đủ thông tin cần thiết", "Lỗi!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                NguoiQuanLy ql = new NguoiQuanLy();
                ql.MyName = txtName.Text;
                ql.MyAvatar = btnUpload_avatar.Text;
              
                ql.ChucVuWork = (ChucVuQuanLy)cbk_listChucVU.Items[cbk_listChucVU.SelectedIndex];
                MessageBox.Show("Đăng ký nhận quầy thành công!", "Thành công!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
                AcForm.quanly = ql;
             
                AcForm.loadprofile();
                AcForm.Enabled = true;
                this.Close();
               
            }
        }

        private void frmNguoi_Quan_Ly_Load(object sender, EventArgs e)
        {
            foreach (ChucVuQuanLy ql in Enum.GetValues(typeof(ChucVuQuanLy)))
            {
                cbk_listChucVU.Items.Add(ql);
            }

        }
    }
}
