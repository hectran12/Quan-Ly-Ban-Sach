﻿namespace Quan_Ly_Ban_Sach
{
    public partial class frmQuanLySach : Form
    {
        static Setting_CuaHang sCH = new Setting_CuaHang();
        public NguoiQuanLy quanly = null;
        public static string load_profile = "";
        public string loadform = "";
        static DanhSachKhanhHang database = new DanhSachKhanhHang();
        
        public frmQuanLySach()
        {
          
            InitializeComponent();
        }

        private void frmQuanLySach_Load(object sender, EventArgs e)
        {
            
            cbk_isStudent.Text = "Nếu là sinh viên thì bấm vào ( giảm " + sCH.Giam_Gia + "% )";
            cbk_isStudent.ForeColor = Color.Red;
            new_phien();
           



        }

        private void new_phien()
        {
            frmNguoi_Quan_Ly quanlyz = new frmNguoi_Quan_Ly();
            quanlyz.Show();
            quanlyz.AcForm = this;
            quanlyz.Enabled = false;
            Thread.Sleep(1000);
            this.Enabled = false;
            quanlyz.Enabled = true;
            quanlyz.Focus();

        }
        public void loadprofile()
        {
            lbl_name_ql.Text = quanly.MyName;
            lbl_chucvu.Text = quanly.ChucVuWork.ToString();
            Image img = Image.FromFile(quanly.MyAvatar);
            lbl_time.Text = DateTime.Now.ToString("dd/MM/yyy HH:mm:ss");
            lbl_time.ForeColor = Color.Green;
            ptBox_avatar.Image = img;
            switch (quanly.ChucVuWork)
            {
                case ChucVuQuanLy.CHI_QUAN_LY:
                    changecolor_chuvu(Color.Pink);
                    break;
                case ChucVuQuanLy.ONG_GIAM_DOC:
                    changecolor_chuvu(Color.Red);
                    break;
                case ChucVuQuanLy.CHU_THU_VIEN:
                    changecolor_chuvu(Color.Purple);
                    break;
                case ChucVuQuanLy.NGUOI_DOC_SACH:
                    changecolor_chuvu(Color.Green);
                    break;
                case ChucVuQuanLy.NGUOI_COI_HO:
                    changecolor_chuvu(Color.DarkBlue);
                    break;
                default:
                    changecolor_chuvu(Color.Black);
                    break;
            }
           
        }

        private void changecolor_chuvu (Color color)
        {
            lbl_chucvu.ForeColor = color;
        }
        private void VIEWAUTHORFUNCTION(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            MessageBox.Show(btn.Tag.ToString(), "Thông tin người viết", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_thayphien_Click(object sender, EventArgs e)
        {
            new_phien();
        }

        private void btn_total_Click(object sender, EventArgs e)
        {
            if(txtNameKhanhHang.Text == "" || txtAMBook.Text == "")
            {
                baoLoi("Bạn chưa nhập đủ!");
            }else
            {
                KhanhHang kh = new KhanhHang();
                kh.FullName = txtNameKhanhHang.Text;
                kh.soCuonMUA = Convert.ToInt32(txtAMBook.Text);
                if (cbk_isStudent.Checked)
                {
                    kh.TangLo = TangLop.SINH_VIEN;
                    kh.GiamGia = sCH.Giam_Gia;
                } else
                {
                    kh.TangLo = TangLop.KHACH_BINH_THUONG;
                    kh.GiamGia = 0;
                }
                kh.TongTien = Convert.ToDouble(txtTotalAMBook.Text);
                kh.thoigianmua = DateTime.Now;
                database.Add(kh);
                reload_history();
                baoThanHCong("Hoàn tất thêm!");
            }
        }

        private void baoLoi (string text)
        {
            MessageBox.Show(text, "Lỗi!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void baoThanHCong (string text)
        {
            MessageBox.Show(text, "Thành công!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void txtAMBook_TextChanged(object sender, EventArgs e)
        {
            TinhTien(txtAMBook);
        }
        private void TinhTien(Control item)
        {
            try
            {
                double tongsoGG = 0;
                if (cbk_isStudent.Checked)
                {
                    tongsoGG = TintPhanTram(Convert.ToInt32(sCH.Giam_Gia), Convert.ToInt32(txtAMBook.Text) * sCH.Gia_1_Quyen_Sach);
                }
                else
                {
                    tongsoGG = Convert.ToInt32(txtAMBook.Text) * sCH.Gia_1_Quyen_Sach;
                }

                
                txtTotalAMBook.Text = Convert.ToString(tongsoGG);
            }
            catch
            {
                baoLoi("Đừng nhập chữ vào ô text");
                item.Text = "";
            }
        }
        private double TintPhanTram (int phantram, int so)
        {
            int NewPT = 100 - phantram;
            string cPT = "0." + NewPT;
            double KQ_PT = Convert.ToDouble(cPT);
            return so * KQ_PT;
        }

        private void cbk_isStudent_CheckedChanged(object sender, EventArgs e)
        {
            TinhTien(txtAMBook);
        }

        private void reload_history()
        {
            int stt = 0;
          
            lsb_history.Items.Clear();
            foreach (KhanhHang kh in database.GetALLkHACHHANG)
            {
                
                if(stt == nud_all.Value)
                {
                    break;
                } else
                {
                    stt++;
                    lsb_history.Items.Add(kh);
                }
            }
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            txtAMBook.Text = "0";
            txtNameKhanhHang.Text = "0";
            txtTotalAMBook.Text = "";
            cbk_isStudent.Checked = false;
        }

        private void btn_reload_Click(object sender, EventArgs e)
        {
            reload_history();
        }

        private void btn_tKE_Click(object sender, EventArgs e)
        {
            txtAllKHToPay.Text = Convert.ToString(database.GetALLkHACHHANG.Count);
            txtAllDoanhThu.Text = Convert.ToString(database.TongSoDoanhThu);
            txtAllStudentToPay.Text = Convert.ToString(database.GetALLSinhVien.Count);
        }

        private void lsb_history_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lsb_history.SelectedIndex != -1)
            {
                KhanhHang kh = (KhanhHang)lsb_history.Items[lsb_history.SelectedIndex];
                kh.ToMessageBoard();
            }
        }

        private void txtAllKHToPay_DoubleClick(object sender, EventArgs e)
        {
            XemChiTiet view = new XemChiTiet(database,"no");
            view.name = "Toàn bộ khách hàng";
            if(view.ShowDialog() == DialogResult.OK)
            {
                reload_history();
            }
        }

        private void txtAllKHToPay_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAllStudentToPay_DoubleClick(object sender, EventArgs e)
        {
            XemChiTiet view = new XemChiTiet(database, "sv");
            view.name = "Sinh viên mua sách";
            if (view.ShowDialog() == DialogResult.OK)
            {
                reload_history();

            }
        }
    }
}