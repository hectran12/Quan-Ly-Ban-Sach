﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quan_Ly_Ban_Sach
{
    internal partial class XemChiTiet : Form
    {
        static DanhSachKhanhHang database= new DanhSachKhanhHang();
        static string typez = "";
        public string name = "";
        public XemChiTiet(DanhSachKhanhHang dskh,string type)
        {
            database = dskh;
            typez = type;
            InitializeComponent();
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if(lsb_chititet.SelectedItems.Count > 0)
            {
                foreach (var item in lsb_chititet.SelectedItems)
                {
                    try
                    {
                        database.Remove((KhanhHang)item);

                    }
                    catch
                    {
                        break;
                    }
                    
                }
                reload_lsb();
            }
        }

        private void XemChiTiet_Load(object sender, EventArgs e)
        {
            lbl_ttchit.Text += " "+ name + " -";
            reload_lsb();
        }
        private void reload_lsb()
        {
            lsb_chititet.Items.Clear();
            foreach (KhanhHang kh in database.GetALLkHACHHANG)
            {
                if(typez == "sv")
                {
                    if(kh.TangLo == TangLop.SINH_VIEN)
                    {
                        lsb_chititet.Items.Add(kh);
                    }
                } else
                {
                    lsb_chititet.Items.Add(kh);
                }
                
            }
        }

        private void XemChiTiet_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void btn_viewmore_Click(object sender, EventArgs e)
        {
            if (lsb_chititet.SelectedItems.Count > 0)
            {
                foreach (KhanhHang item in lsb_chititet.SelectedItems)
                {
                    try
                    {
                        item.ToMessageBoard();
                    }
                    catch
                    {
                        break;
                    }

                }
                reload_lsb();
            }
        }
    }
}
