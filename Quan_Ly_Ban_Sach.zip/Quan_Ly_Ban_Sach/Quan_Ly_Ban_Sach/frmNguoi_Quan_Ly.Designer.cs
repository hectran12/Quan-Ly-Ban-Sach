﻿namespace Quan_Ly_Ban_Sach
{
    partial class frmNguoi_Quan_Ly
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_hoanthanh = new System.Windows.Forms.Button();
            this.cbk_listChucVU = new System.Windows.Forms.ComboBox();
            this.btnUpload_avatar = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(347, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Điền thông tin người nhận quầy";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.Controls.Add(this.btn_hoanthanh);
            this.panel1.Controls.Add(this.cbk_listChucVU);
            this.panel1.Controls.Add(this.btnUpload_avatar);
            this.panel1.Controls.Add(this.txtName);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(12, 40);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(323, 112);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btn_hoanthanh
            // 
            this.btn_hoanthanh.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_hoanthanh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_hoanthanh.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_hoanthanh.ForeColor = System.Drawing.Color.White;
            this.btn_hoanthanh.Location = new System.Drawing.Point(15, 67);
            this.btn_hoanthanh.Name = "btn_hoanthanh";
            this.btn_hoanthanh.Size = new System.Drawing.Size(290, 31);
            this.btn_hoanthanh.TabIndex = 4;
            this.btn_hoanthanh.Text = "Hoàn thành cài đặt";
            this.btn_hoanthanh.UseVisualStyleBackColor = false;
            this.btn_hoanthanh.Click += new System.EventHandler(this.btn_hoanthanh_Click);
            // 
            // cbk_listChucVU
            // 
            this.cbk_listChucVU.FormattingEnabled = true;
            this.cbk_listChucVU.Location = new System.Drawing.Point(158, 38);
            this.cbk_listChucVU.Name = "cbk_listChucVU";
            this.cbk_listChucVU.Size = new System.Drawing.Size(147, 23);
            this.cbk_listChucVU.TabIndex = 3;
            // 
            // btnUpload_avatar
            // 
            this.btnUpload_avatar.Location = new System.Drawing.Point(15, 38);
            this.btnUpload_avatar.Name = "btnUpload_avatar";
            this.btnUpload_avatar.Size = new System.Drawing.Size(137, 23);
            this.btnUpload_avatar.TabIndex = 2;
            this.btnUpload_avatar.Text = "Upload ảnh đại diện";
            this.btnUpload_avatar.UseVisualStyleBackColor = true;
            this.btnUpload_avatar.Click += new System.EventHandler(this.btnUpload_avatar_Click);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(82, 9);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(223, 23);
            this.txtName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Họ và tên:";
            // 
            // frmNguoi_Quan_Ly
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(347, 166);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmNguoi_Quan_Ly";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cài đặt thông tin người quản lý";
            this.Load += new System.EventHandler(this.frmNguoi_Quan_Ly_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Label label1;
        private Panel panel1;
        private Button btnUpload_avatar;
        private TextBox txtName;
        private Label label2;
        private Button btn_hoanthanh;
        private ComboBox cbk_listChucVU;
    }
}