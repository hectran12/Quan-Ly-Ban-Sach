﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quan_Ly_Ban_Sach
{
    internal class KhanhHang
    {
        public string FullName { get; set; }
        public int soCuonMUA { get; set; }
        public Double TongTien { get; set; }
        public int GiamGia { get; set; }
        public TangLop TangLo { get; set; }
        public DateTime thoigianmua { get; set; }

        public override string ToString()
        {
            return thoigianmua.ToString("dd/MM/yyyy HH:mm:ss") + " => " + FullName + " => " + TongTien + "VNĐ";
        }
        public void ToMessageBoard()
        {
            string MessageBoard = "Họ tên: " + FullName
                + "\n" + "Số sách mua: " + soCuonMUA
                + "\n" + "Tổng tiền đã trả: " + TongTien + "VNĐ"
                + "\n" + "Được giảm giá: " + GiamGia + "%"
                + "\n" + "Tâng lớp: " + TangLo.ToString()
                + "\n" + "Thời gian mua: " + thoigianmua;
            MessageBox.Show(MessageBoard, "Xem lịch sử của một giao dịch!");
        }
    }
}
