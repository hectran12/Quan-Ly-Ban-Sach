﻿namespace Quan_Ly_Ban_Sach
{
    partial class XemChiTiet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_ttchit = new System.Windows.Forms.Label();
            this.lsb_chititet = new System.Windows.Forms.ListBox();
            this.btn_remove = new System.Windows.Forms.Button();
            this.btn_viewmore = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_ttchit
            // 
            this.lbl_ttchit.BackColor = System.Drawing.SystemColors.Highlight;
            this.lbl_ttchit.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_ttchit.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_ttchit.ForeColor = System.Drawing.SystemColors.Control;
            this.lbl_ttchit.Location = new System.Drawing.Point(0, 0);
            this.lbl_ttchit.Name = "lbl_ttchit";
            this.lbl_ttchit.Size = new System.Drawing.Size(423, 59);
            this.lbl_ttchit.TabIndex = 0;
            this.lbl_ttchit.Text = "Thông tin chi tiết -";
            this.lbl_ttchit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lsb_chititet
            // 
            this.lsb_chititet.FormattingEnabled = true;
            this.lsb_chititet.ItemHeight = 15;
            this.lsb_chititet.Location = new System.Drawing.Point(12, 72);
            this.lsb_chititet.Name = "lsb_chititet";
            this.lsb_chititet.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lsb_chititet.Size = new System.Drawing.Size(399, 334);
            this.lsb_chititet.TabIndex = 1;
            // 
            // btn_remove
            // 
            this.btn_remove.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_remove.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_remove.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_remove.ForeColor = System.Drawing.Color.White;
            this.btn_remove.Location = new System.Drawing.Point(350, 415);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(61, 23);
            this.btn_remove.TabIndex = 4;
            this.btn_remove.Text = "Xóa";
            this.btn_remove.UseVisualStyleBackColor = false;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // btn_viewmore
            // 
            this.btn_viewmore.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_viewmore.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_viewmore.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_viewmore.ForeColor = System.Drawing.Color.White;
            this.btn_viewmore.Location = new System.Drawing.Point(242, 415);
            this.btn_viewmore.Name = "btn_viewmore";
            this.btn_viewmore.Size = new System.Drawing.Size(102, 23);
            this.btn_viewmore.TabIndex = 5;
            this.btn_viewmore.Text = "Xem chi tiết";
            this.btn_viewmore.UseVisualStyleBackColor = false;
            this.btn_viewmore.Click += new System.EventHandler(this.btn_viewmore_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 419);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "Phần mềm được viết bởi Hex Trần";
            // 
            // XemChiTiet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_viewmore);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.lsb_chititet);
            this.Controls.Add(this.lbl_ttchit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "XemChiTiet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "XemChiTiet";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.XemChiTiet_FormClosing);
            this.Load += new System.EventHandler(this.XemChiTiet_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lbl_ttchit;
        private ListBox lsb_chititet;
        private Button btn_remove;
        private Button btn_viewmore;
        private Label label2;
    }
}