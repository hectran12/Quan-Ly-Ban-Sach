﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quan_Ly_Ban_Sach
{
    public class NguoiQuanLy
    {
        public string MyName { get; set; }
        public string MyAvatar { get; set; }
        public ChucVuQuanLy ChucVuWork { get; set; }

    }
}
