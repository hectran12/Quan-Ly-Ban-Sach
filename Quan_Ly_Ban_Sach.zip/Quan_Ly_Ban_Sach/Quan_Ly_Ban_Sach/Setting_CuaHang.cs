﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quan_Ly_Ban_Sach
{
    public class Setting_CuaHang
    {
        public int Giam_Gia = 10;
        public int Gia_1_Quyen_Sach = 20000;

    }
}
