﻿namespace Quan_Ly_Ban_Sach
{
    partial class frmQuanLySach
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtAllDoanhThu = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAllStudentToPay = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtAllKHToPay = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_total = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.btn_tKE = new System.Windows.Forms.Button();
            this.btn_next = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtTotalAMBook = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbk_isStudent = new System.Windows.Forms.CheckBox();
            this.txtAMBook = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNameKhanhHang = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_thayphien = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl_time = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_chucvu = new System.Windows.Forms.Label();
            this.lbl_name_ql = new System.Windows.Forms.Label();
            this.ptBox_avatar = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_reload = new System.Windows.Forms.Button();
            this.nud_all = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lsb_history = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptBox_avatar)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_all)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Highlight;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(653, 57);
            this.label1.TabIndex = 0;
            this.label1.Text = "Quản lý bán sách";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Location = new System.Drawing.Point(12, 69);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(359, 443);
            this.panel1.TabIndex = 1;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox4.Controls.Add(this.button6);
            this.groupBox4.Controls.Add(this.button5);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Location = new System.Drawing.Point(16, 354);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(328, 76);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ControlText;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button6.Location = new System.Drawing.Point(156, 47);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(166, 23);
            this.button6.TabIndex = 3;
            this.button6.Tag = "https://github.com/hexzzz2008";
            this.button6.Text = "GITHUB: HEXZZ2008";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.VIEWAUTHORFUNCTION);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.button5.Location = new System.Drawing.Point(6, 47);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(144, 23);
            this.button5.TabIndex = 2;
            this.button5.Tag = "https://www.facebook.com/thehex101";
            this.button5.Text = "FB: TRẦN TRỌNG HÒA";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.VIEWAUTHORFUNCTION);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label9.Location = new System.Drawing.Point(197, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 15);
            this.label9.TabIndex = 1;
            this.label9.Text = "Trần Trọng Hòa";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label7.Location = new System.Drawing.Point(6, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(185, 15);
            this.label7.TabIndex = 0;
            this.label7.Text = "Phần mềm được viết & thiết kế bởi:";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox3.Controls.Add(this.txtAllDoanhThu);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txtAllStudentToPay);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.txtAllKHToPay);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(16, 225);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(328, 123);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Nhập thông tin người mua:";
            // 
            // txtAllDoanhThu
            // 
            this.txtAllDoanhThu.Location = new System.Drawing.Point(115, 80);
            this.txtAllDoanhThu.Name = "txtAllDoanhThu";
            this.txtAllDoanhThu.ReadOnly = true;
            this.txtAllDoanhThu.Size = new System.Drawing.Size(191, 23);
            this.txtAllDoanhThu.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 15);
            this.label6.TabIndex = 13;
            this.label6.Text = "Tổng doanh thu:";
            // 
            // txtAllStudentToPay
            // 
            this.txtAllStudentToPay.Location = new System.Drawing.Point(115, 51);
            this.txtAllStudentToPay.Name = "txtAllStudentToPay";
            this.txtAllStudentToPay.ReadOnly = true;
            this.txtAllStudentToPay.Size = new System.Drawing.Size(191, 23);
            this.txtAllStudentToPay.TabIndex = 12;
            this.txtAllStudentToPay.DoubleClick += new System.EventHandler(this.txtAllStudentToPay_DoubleClick);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 54);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 15);
            this.label8.TabIndex = 11;
            this.label8.Text = "Tổng số SV:";
            // 
            // txtAllKHToPay
            // 
            this.txtAllKHToPay.Location = new System.Drawing.Point(115, 22);
            this.txtAllKHToPay.Name = "txtAllKHToPay";
            this.txtAllKHToPay.ReadOnly = true;
            this.txtAllKHToPay.Size = new System.Drawing.Size(191, 23);
            this.txtAllKHToPay.TabIndex = 6;
            this.txtAllKHToPay.TextChanged += new System.EventHandler(this.txtAllKHToPay_TextChanged);
            this.txtAllKHToPay.DoubleClick += new System.EventHandler(this.txtAllKHToPay_DoubleClick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "Tổng số KH:";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox2.Controls.Add(this.btn_total);
            this.groupBox2.Controls.Add(this.btn_exit);
            this.groupBox2.Controls.Add(this.btn_tKE);
            this.groupBox2.Controls.Add(this.btn_next);
            this.groupBox2.Location = new System.Drawing.Point(16, 164);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(328, 55);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // btn_total
            // 
            this.btn_total.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_total.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_total.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_total.ForeColor = System.Drawing.Color.White;
            this.btn_total.Location = new System.Drawing.Point(6, 22);
            this.btn_total.Name = "btn_total";
            this.btn_total.Size = new System.Drawing.Size(75, 23);
            this.btn_total.TabIndex = 3;
            this.btn_total.Text = "T.tiền";
            this.btn_total.UseVisualStyleBackColor = false;
            this.btn_total.Click += new System.EventHandler(this.btn_total_Click);
            // 
            // btn_exit
            // 
            this.btn_exit.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_exit.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_exit.ForeColor = System.Drawing.Color.White;
            this.btn_exit.Location = new System.Drawing.Point(247, 22);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(75, 23);
            this.btn_exit.TabIndex = 2;
            this.btn_exit.Text = "Thoát";
            this.btn_exit.UseVisualStyleBackColor = false;
            // 
            // btn_tKE
            // 
            this.btn_tKE.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_tKE.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_tKE.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_tKE.ForeColor = System.Drawing.Color.White;
            this.btn_tKE.Location = new System.Drawing.Point(168, 22);
            this.btn_tKE.Name = "btn_tKE";
            this.btn_tKE.Size = new System.Drawing.Size(75, 23);
            this.btn_tKE.TabIndex = 2;
            this.btn_tKE.Text = "T.Kê";
            this.btn_tKE.UseVisualStyleBackColor = false;
            this.btn_tKE.Click += new System.EventHandler(this.btn_tKE_Click);
            // 
            // btn_next
            // 
            this.btn_next.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_next.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_next.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_next.ForeColor = System.Drawing.Color.White;
            this.btn_next.Location = new System.Drawing.Point(87, 22);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(75, 23);
            this.btn_next.TabIndex = 1;
            this.btn_next.Text = "Tiếp";
            this.btn_next.UseVisualStyleBackColor = false;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Controls.Add(this.txtTotalAMBook);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cbk_isStudent);
            this.groupBox1.Controls.Add(this.txtAMBook);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtNameKhanhHang);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(16, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(328, 143);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Nhập thông tin người mua:";
            // 
            // txtTotalAMBook
            // 
            this.txtTotalAMBook.Location = new System.Drawing.Point(115, 109);
            this.txtTotalAMBook.Name = "txtTotalAMBook";
            this.txtTotalAMBook.ReadOnly = true;
            this.txtTotalAMBook.Size = new System.Drawing.Size(191, 23);
            this.txtTotalAMBook.TabIndex = 6;
            this.txtTotalAMBook.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "Thành tiền:";
            // 
            // cbk_isStudent
            // 
            this.cbk_isStudent.AutoSize = true;
            this.cbk_isStudent.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbk_isStudent.Location = new System.Drawing.Point(16, 84);
            this.cbk_isStudent.Name = "cbk_isStudent";
            this.cbk_isStudent.Size = new System.Drawing.Size(251, 19);
            this.cbk_isStudent.TabIndex = 4;
            this.cbk_isStudent.Text = "Khánh hàng là sinh viên ( giảm phantram )";
            this.cbk_isStudent.UseVisualStyleBackColor = true;
            this.cbk_isStudent.CheckedChanged += new System.EventHandler(this.cbk_isStudent_CheckedChanged);
            // 
            // txtAMBook
            // 
            this.txtAMBook.Location = new System.Drawing.Point(168, 55);
            this.txtAMBook.Name = "txtAMBook";
            this.txtAMBook.Size = new System.Drawing.Size(138, 23);
            this.txtAMBook.TabIndex = 3;
            this.txtAMBook.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtAMBook.TextChanged += new System.EventHandler(this.txtAMBook_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Số lượng sách muốn mua:";
            // 
            // txtNameKhanhHang
            // 
            this.txtNameKhanhHang.Location = new System.Drawing.Point(115, 26);
            this.txtNameKhanhHang.Name = "txtNameKhanhHang";
            this.txtNameKhanhHang.Size = new System.Drawing.Size(191, 23);
            this.txtNameKhanhHang.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tên khách hàng:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel2.Controls.Add(this.btn_thayphien);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Location = new System.Drawing.Point(377, 69);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(268, 142);
            this.panel2.TabIndex = 2;
            // 
            // btn_thayphien
            // 
            this.btn_thayphien.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_thayphien.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_thayphien.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_thayphien.ForeColor = System.Drawing.Color.White;
            this.btn_thayphien.Location = new System.Drawing.Point(17, 110);
            this.btn_thayphien.Name = "btn_thayphien";
            this.btn_thayphien.Size = new System.Drawing.Size(234, 23);
            this.btn_thayphien.TabIndex = 1;
            this.btn_thayphien.Text = "Thay phiên mới!";
            this.btn_thayphien.UseVisualStyleBackColor = false;
            this.btn_thayphien.Click += new System.EventHandler(this.btn_thayphien_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel4.Controls.Add(this.lbl_time);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.lbl_chucvu);
            this.panel4.Controls.Add(this.lbl_name_ql);
            this.panel4.Controls.Add(this.ptBox_avatar);
            this.panel4.Location = new System.Drawing.Point(17, 13);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(234, 91);
            this.panel4.TabIndex = 0;
            // 
            // lbl_time
            // 
            this.lbl_time.AutoSize = true;
            this.lbl_time.Location = new System.Drawing.Point(99, 48);
            this.lbl_time.Name = "lbl_time";
            this.lbl_time.Size = new System.Drawing.Size(31, 15);
            this.lbl_time.TabIndex = 4;
            this.lbl_time.Text = "time";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(99, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(111, 15);
            this.label10.TabIndex = 3;
            this.label10.Text = "Tham gia phiên lúc:";
            // 
            // lbl_chucvu
            // 
            this.lbl_chucvu.AutoSize = true;
            this.lbl_chucvu.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_chucvu.Location = new System.Drawing.Point(99, 63);
            this.lbl_chucvu.Name = "lbl_chucvu";
            this.lbl_chucvu.Size = new System.Drawing.Size(97, 17);
            this.lbl_chucvu.TabIndex = 2;
            this.lbl_chucvu.Text = "Người thường";
            // 
            // lbl_name_ql
            // 
            this.lbl_name_ql.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_name_ql.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbl_name_ql.Location = new System.Drawing.Point(99, 7);
            this.lbl_name_ql.Name = "lbl_name_ql";
            this.lbl_name_ql.Size = new System.Drawing.Size(132, 18);
            this.lbl_name_ql.TabIndex = 1;
            this.lbl_name_ql.Text = "Tên người quản lý";
            // 
            // ptBox_avatar
            // 
            this.ptBox_avatar.Location = new System.Drawing.Point(24, 7);
            this.ptBox_avatar.Name = "ptBox_avatar";
            this.ptBox_avatar.Size = new System.Drawing.Size(69, 73);
            this.ptBox_avatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptBox_avatar.TabIndex = 0;
            this.ptBox_avatar.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel3.Controls.Add(this.btn_reload);
            this.panel3.Controls.Add(this.nud_all);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.lsb_history);
            this.panel3.Location = new System.Drawing.Point(377, 217);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(268, 295);
            this.panel3.TabIndex = 3;
            // 
            // btn_reload
            // 
            this.btn_reload.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_reload.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_reload.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_reload.ForeColor = System.Drawing.Color.White;
            this.btn_reload.Location = new System.Drawing.Point(131, 265);
            this.btn_reload.Name = "btn_reload";
            this.btn_reload.Size = new System.Drawing.Size(120, 23);
            this.btn_reload.TabIndex = 4;
            this.btn_reload.Text = "Reload";
            this.btn_reload.UseVisualStyleBackColor = false;
            this.btn_reload.Click += new System.EventHandler(this.btn_reload_Click);
            // 
            // nud_all
            // 
            this.nud_all.Location = new System.Drawing.Point(76, 265);
            this.nud_all.Name = "nud_all";
            this.nud_all.Size = new System.Drawing.Size(49, 23);
            this.nud_all.TabIndex = 3;
            this.nud_all.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(17, 269);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 15);
            this.label12.TabIndex = 2;
            this.label12.Text = "Lấy lsgd:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label11.Location = new System.Drawing.Point(17, 7);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(131, 21);
            this.label11.TabIndex = 1;
            this.label11.Text = "Lịch sử giao dịch";
            // 
            // lsb_history
            // 
            this.lsb_history.FormattingEnabled = true;
            this.lsb_history.ItemHeight = 15;
            this.lsb_history.Location = new System.Drawing.Point(17, 31);
            this.lsb_history.Name = "lsb_history";
            this.lsb_history.Size = new System.Drawing.Size(234, 229);
            this.lsb_history.TabIndex = 0;
            this.lsb_history.SelectedIndexChanged += new System.EventHandler(this.lsb_history_SelectedIndexChanged);
            // 
            // frmQuanLySach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(653, 524);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frmQuanLySach";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Sách by Hex Trần";
            this.Load += new System.EventHandler(this.frmQuanLySach_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptBox_avatar)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_all)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Label label1;
        private Panel panel1;
        private GroupBox groupBox2;
        private Button btn_exit;
        private Button btn_tKE;
        private Button btn_next;
        private Button btn_ttien;
        private GroupBox groupBox1;
        private TextBox txtTotalAMBook;
        private Label label4;
        private CheckBox cbk_isStudent;
        private TextBox txtAMBook;
        private Label label3;
        private TextBox txtNameKhanhHang;
        private Label label2;
        private GroupBox groupBox4;
        private Button button6;
        private Button button5;
        private Label label9;
        private Label label7;
        private GroupBox groupBox3;
        private TextBox txtAllDoanhThu;
        private Label label6;
        private TextBox txtAllStudentToPay;
        private Label label8;
        private TextBox txtAllKHToPay;
        private Label label5;
        private Panel panel2;
        private PictureBox ptBox_avatar;
        private Panel panel3;
        private Label lbl_chucvu;
        private Label lbl_name_ql;
        private Panel panel4;
        private Label lbl_time;
        private Label label10;
        private Button btn_thayphien;
        private Button btn_reload;
        private NumericUpDown nud_all;
        private Label label12;
        private Label label11;
        private ListBox lsb_history;
        private Button btn_total;
    }
}