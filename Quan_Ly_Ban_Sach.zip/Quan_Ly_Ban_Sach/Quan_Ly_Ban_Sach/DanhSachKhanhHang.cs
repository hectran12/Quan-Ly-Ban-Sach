﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quan_Ly_Ban_Sach
{
    internal class DanhSachKhanhHang
    {
        List<KhanhHang> LISTKhachHang = new List<KhanhHang>();
        public List<KhanhHang> GetALLkHACHHANG
        {
            get { return LISTKhachHang; }
        }
        public List<KhanhHang> GetALLSinhVien
        {
            get
            {
                List<KhanhHang> listSV = new List<KhanhHang>();
                foreach (KhanhHang kh in LISTKhachHang)
                {
                    if (kh.TangLo == TangLop.SINH_VIEN)
                    {
                        listSV.Add(kh);
                    }
                }
                return listSV;
            }
        }

        public double TongSoDoanhThu
        {
            get
            {
                double tongSODT = 0;
                foreach (KhanhHang kh in LISTKhachHang)
                {
                    tongSODT += kh.TongTien;
                }
                return tongSODT;
            }
        }

        public int TongSoSachDaBan
        {
            get
            {
                int TongSODD = 0;
                foreach (KhanhHang kh in LISTKhachHang)
                {
                    TongSODD += kh.soCuonMUA;
                }
                return TongSODD;
            }
        }
        public void Add(KhanhHang kh)
        {
            LISTKhachHang.Add(kh);
        }
        public void Remove(KhanhHang kh)
        {
            LISTKhachHang.Remove(kh);
        }
    }
}
